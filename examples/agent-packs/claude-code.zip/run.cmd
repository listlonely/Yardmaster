@claude -p --output-format stream-json --verbose %*
