@codex exec --json %*
