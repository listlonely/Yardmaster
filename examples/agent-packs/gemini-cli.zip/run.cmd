@gemini -p " " %*
