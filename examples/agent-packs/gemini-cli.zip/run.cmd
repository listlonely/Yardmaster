@gemini -p %*
